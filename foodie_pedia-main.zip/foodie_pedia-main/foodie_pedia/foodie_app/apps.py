from django.apps import AppConfig


class FoodieAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'foodie_app'
